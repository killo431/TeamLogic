
function Initialize-NinjaConfig {
    [CmdletBinding()]
    param (
        [string]$ClientId = "O12UVQDxFHPF-06Q90Z5BsxT7wk",
        [string]$ClientSecret = "m375oYCyXY3frFH9COIqm4vztgNu-0EGel96a7nx9aqMuxuqcRIx1A",
        [string]$Scope = "control management monitoring",
        [string]$BaseApiUrl = "https://app.ninjaone.com/v2"
    )

    Write-Host "[INIT] Starting NinjaOne config initialization..." -ForegroundColor Cyan

    $body = @{
        grant_type    = "client_credentials"
        client_id     = $ClientId
        client_secret = $ClientSecret
        redirect_uri  = "http://localhost"
        scope         = $Scope
    }
    $API_AuthHeaders = @{
        "accept"       = "application/json"
        "Content-Type" = "application/x-www-form-urlencoded"
    }

    Write-Host "[AUTH] Requesting access token..."
    try {
        $auth_token = Invoke-RestMethod -Uri "https://app.ninjaone.com/oauth/token" -Method POST -Headers $API_AuthHeaders -Body $body
        $ApiToken = $auth_token.access_token
        if (-not $ApiToken) {
            throw "Access token not returned."
        }
        Write-Host "[AUTH] Access token received." -ForegroundColor Green
    } catch {
        throw "[ERROR] Failed to retrieve access token: $_"
    }

   function Get-NinjaDeviceId {
    param (
        [string]$Hostname,
        [string]$Token,
        [string]$ApiUrl
    )
    $headers = @{
        "Authorization" = "Bearer $Token"
        "Accept"        = "application/json"
    }
    $url = "$ApiUrl/devices"

    try {
        Write-Host "[LOOKUP] Downloading full device list from NinjaOne..." -ForegroundColor Cyan
        $response = Invoke-RestMethod -Uri $url -Method GET -Headers $headers

        Write-Host "[LOOKUP] Searching for systemName: $Hostname" -ForegroundColor Cyan
        $device = $response | Where-Object { $_.systemName -ieq $Hostname }

        if (-not $device) {
            Write-Host "[WARN] No exact systemName match. Available systems:" -ForegroundColor Yellow
            $response | ForEach-Object {
                Write-Host " - $($_.systemName) → ID: $($_.id)"
            }
            return $null
        }

        Write-Host "[FOUND] systemName: $($device.systemName) → ID: $($device.id)" -ForegroundColor Green
        return $device.id
    } catch {
        Write-Error "Failed to retrieve or match devices: $_"
        return $null
    }
}

    $Hostname = $env:COMPUTERNAME
    Write-Host "[LOOKUP] Resolving Device ID for '$Hostname'..."
    $DeviceId = Get-NinjaDeviceId -Hostname $Hostname -Token $ApiToken -ApiUrl $BaseApiUrl
    if (-not $DeviceId) {
        throw "❌ Could not resolve Device ID from NinjaOne for hostname: $Hostname"
    } else {
        Write-Host "[FOUND] Device ID = $DeviceId" -ForegroundColor Green
    }

    return [PSCustomObject]@{
        ApiToken    = $ApiToken
        DeviceId    = $DeviceId
        BaseApiUrl  = $BaseApiUrl
        Headers     = @{
            "Authorization" = "Bearer $ApiToken"
            "Accept"        = "application/json"
        }
    }
}
