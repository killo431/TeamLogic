
Import-Module "$PSScriptRoot\..\NinjaOneTools.psm1" -Force

# Initialize NinjaOne config
$config = Initialize-NinjaConfig

$ApiToken   = $config.ApiToken
$DeviceId   = $config.DeviceId
$BaseApiUrl = $config.BaseApiUrl
$Headers    = $config.Headers

# Define RustDesk URL and paths
$rustDeskUrl = "https://raw.githubusercontent.com/killo431/TeamLogic/main/rustdesk-1.3.9-x86_64.msi"
$installerPath = "$env:TEMP\rustdesk_installer.msi"
$configDir = "$env:APPDATA\RustDesk"
$jsonPath = Join-Path $configDir "config.json"

# Download RustDesk
Write-Host "[DOWNLOAD] Fetching RustDesk installer..."
Start-BitsTransfer -Source $rustDeskUrl -Destination $installerPath


# Install RustDesk silently
Write-Host "[INSTALL] Running silent RustDesk install..."
Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$installerPath`" /qn" -Wait

# Ensure config directory
New-Item -ItemType Directory -Path $configDir -Force | Out-Null

# Create basic unattended config
$rdeskId = Get-Random -Minimum 100000000 -Maximum 999999999
$rdeskPwd = -join ((33..126) | Get-Random -Count 12 | ForEach-Object {[char]$_})

$config = @{
    id = "$rdeskId"
    password = "$rdeskPwd"
    relay = "public.relay.rustdesk.com"
    use_custom_server = $false
}
$config | ConvertTo-Json -Depth 5 | Set-Content -Path $jsonPath -Encoding UTF8

# Define custom field name
[string]$CustomField = "RustC"

# Create log file
$logPath = "$env:ProgramData\RustDeskDeploy.log"

# Format the results
$Results = "RustDesk ID: $rdeskId | Password: $rdeskPwd | Timestamp: $(Get-Date -Format s)"

# Write to log file
$Results | Out-File -FilePath $logPath

# Output the results to console
Write-Output $Results
Write-Host $Results

# Set NinjaRMM custom field if available
Write-Host "[NINJAONE] Setting custom field..."
if (Get-Command "Ninja-Property-Set" -ErrorAction SilentlyContinue) {
    Ninja-Property-Set -Name $CustomField -Value $Results
    Write-Host "Ninja-Property-Set executed successfully with CustomField: $CustomField"
} else {
    Write-Host "Ninja-Property-Set command not found. Using API method instead."
    
    # Alternative method using API
    $customFieldBody = @{
        deviceId = $DeviceId
        customFields = @{
            $CustomField = $Results
        }
    }
    try {
        Invoke-RestMethod -Uri "$BaseApiUrl/device/custom-fields" -Method PATCH -Headers $Headers -Body ($customFieldBody | ConvertTo-Json -Depth 10)
        Write-Host "Custom field set via API successfully."
    } catch {
        Write-Host "Failed to set custom field via API: $_"
        
        # Fallback to note method
        $noteBody = @{
            deviceId = $DeviceId
            note     = "🛠️ RustDesk installed.`nID: $rdeskId`nPassword: $rdeskPwd`n$(Get-Date -Format s)"
            type     = "info"
        }
        Invoke-RestMethod -Uri "$BaseApiUrl/device-notes" -Method POST -Headers $Headers -Body ($noteBody | ConvertTo-Json -Depth 10)
        Write-Host "Fallback to note method successful."
    }
}

Write-Host "[DONE] RustDesk deployed and info synced to NinjaOne." -ForegroundColor Green
