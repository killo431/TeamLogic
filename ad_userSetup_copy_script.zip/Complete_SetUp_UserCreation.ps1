# New Employee Complete Setup Launcher Script
# Creates AD user, Exchange mailbox, joins domain, and installs software

param(
    [Parameter(Mandatory=$true)]
    [string]$JsonFilePath,
    
    [switch]$SkipDeviceSetup
)

Write-Host "=== CGS New Employee Complete Setup ===" -ForegroundColor Magenta
Write-Host "Creates user accounts and sets up device" -ForegroundColor Yellow

# Validate JSON file exists
if (-not (Test-Path $JsonFilePath)) {
    Write-Error "JSON file not found: $JsonFilePath"
    exit 1
}

# Read JSON to get employee info
try {
    $jsonContent = Get-Content -Path $JsonFilePath -Raw | ConvertFrom-Json
    
    # Extract employee information
    $firstName = ""
    $lastName = ""
    $userEmail = ""
    $setupType = ""
    
    foreach ($section in $jsonContent) {
        foreach ($item in $section.items) {
            if ($item.question -eq "First Name") { $firstName = $item.answer }
            if ($item.question -eq "Last Name") { $lastName = $item.answer }
            if ($item.question -eq "User Email?") { $userEmail = $item.answer }
            if ($item.question -eq "New Setup or Transfer?") { $setupType = $item.answer }
        }
    }
    
    Write-Host "New Employee: $firstName $lastName" -ForegroundColor Green
    Write-Host "Email: $userEmail" -ForegroundColor Green
    Write-Host "Setup Type: $setupType" -ForegroundColor Green
}
catch {
    Write-Error "Failed to read JSON file: $($_.Exception.Message)"
    exit 1
}

Write-Host "`nThis launcher will:" -ForegroundColor Cyan
Write-Host "1. Create Active Directory user account" -ForegroundColor White
Write-Host "2. Create Exchange Online mailbox and email" -ForegroundColor White
if (-not $SkipDeviceSetup) {
    Write-Host "3. Join computer to domain Austin.cgs" -ForegroundColor White
    Write-Host "4. Install required software" -ForegroundColor White
}

$confirm = Read-Host "`nProceed with new employee setup? (Y/N)"
if ($confirm -ne 'Y' -and $confirm -ne 'y') {
    Write-Host "Setup cancelled" -ForegroundColor Yellow
    exit 0
}

# Initialize credentials log
$credentialsFile = ".\Created_Credentials_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
$logContent = @"
=== CGS NEW EMPLOYEE CREDENTIALS ===
Employee: $firstName $lastName
Email: $userEmail
Setup Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Setup Type: $setupType

"@

# Step 1: Create AD User
Write-Host "`n=== STEP 1: ACTIVE DIRECTORY USER CREATION ===" -ForegroundColor Yellow
Write-Host "Creating AD user account..." -ForegroundColor Cyan

try {
    & ".\ad_userSetup_copy_script.ps1" -ImportJsonFile $JsonFilePath
    if ($LASTEXITCODE -ne 0) {
        throw "AD user creation failed"
    }
    
    $username = $userEmail.Split('@')[0]
    $adPassword = "WelcomeCGSDB25"
    
    $logContent += @"
ACTIVE DIRECTORY ACCOUNT:
Username: $username
Password: $adPassword
Domain: Austin.cgs
Status: Created successfully
Password Change Required: No

"@
    
    Write-Host "✓ AD user created successfully" -ForegroundColor Green
}
catch {
    Write-Error "AD user creation failed: $($_.Exception.Message)"
    $logContent += @"
ACTIVE DIRECTORY ACCOUNT:
Status: FAILED - $($_.Exception.Message)

"@
}

# Step 2: Create Exchange User
Write-Host "`n=== STEP 2: EXCHANGE ONLINE SETUP ===" -ForegroundColor Yellow
Write-Host "Creating Exchange mailbox and email..." -ForegroundColor Cyan

try {
    # Note: Exchange script needs to be modified to accept JSON input
    Write-Host "⚠ Exchange setup requires manual configuration" -ForegroundColor Yellow
    Write-Host "Please run exchange_user_script.ps1 separately" -ForegroundColor Yellow
    
    $logContent += @"
EXCHANGE ONLINE ACCOUNT:
Email: $userEmail
Status: Manual setup required
Note: Run exchange_user_script.ps1 to complete email setup

"@
}
catch {
    Write-Error "Exchange setup failed: $($_.Exception.Message)"
    $logContent += @"
EXCHANGE ONLINE ACCOUNT:
Status: FAILED - $($_.Exception.Message)

"@
}

if (-not $SkipDeviceSetup) {
    # Step 3: Domain Join
    Write-Host "`n=== STEP 3: DOMAIN JOIN ===" -ForegroundColor Yellow
    Write-Host "Joining computer to domain..." -ForegroundColor Cyan

    try {
        & ".\domain_join_script.ps1" -JsonFilePath $JsonFilePath
        if ($LASTEXITCODE -ne 0) {
            throw "Domain join failed"
        }
        
        $logContent += @"
COMPUTER DOMAIN JOIN:
Domain: Austin.cgs
Status: Completed successfully
Computer Name: CGS-$($firstName.Substring(0,1).ToUpper())$lastName-$((Get-Date).Year)

"@
        
        Write-Host "✓ Domain join completed" -ForegroundColor Green
    }
    catch {
        Write-Error "Domain join failed: $($_.Exception.Message)"
        $logContent += @"
COMPUTER DOMAIN JOIN:
Status: FAILED - $($_.Exception.Message)

"@
    }

    # Step 4: Software Installation
    Write-Host "`n=== STEP 4: SOFTWARE INSTALLATION ===" -ForegroundColor Yellow
    Write-Host "Installing required software..." -ForegroundColor Cyan

    try {
        & ".\software_install_script.ps1" -JsonFilePath $JsonFilePath
        
        # Get software list from JSON
        $softwareList = ""
        foreach ($section in $jsonContent) {
            foreach ($item in $section.items) {
                if ($item.question -eq "What software does the employee need?") {
                    $softwareList = $item.answer
                    break
                }
            }
        }
        
        $logContent += @"
SOFTWARE INSTALLATION:
Required Software: $softwareList
Status: Installation attempted
Note: Check individual software for installation success

"@
        
        Write-Host "✓ Software installation completed" -ForegroundColor Green
    }
    catch {
        Write-Error "Software installation encountered errors: $($_.Exception.Message)"
        $logContent += @"
SOFTWARE INSTALLATION:
Status: FAILED - $($_.Exception.Message)

"@
    }
}

# Save credentials file
$logContent += @"

=== SETUP SUMMARY ===
Completed: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Credentials File: $credentialsFile

NEXT STEPS:
1. Complete Exchange Online setup manually
2. Restart computer to finalize domain join
3. Test user login with domain credentials
4. Verify all software installations
5. Provide credentials to new employee

=== END OF SETUP LOG ===
"@

$logContent | Out-File -FilePath $credentialsFile -Encoding UTF8

Write-Host "`n=== NEW EMPLOYEE SETUP COMPLETE ===" -ForegroundColor Green
Write-Host "Employee: $firstName $lastName" -ForegroundColor White
Write-Host "Credentials saved to: $credentialsFile" -ForegroundColor Yellow

Write-Host "`nCredentials Summary:" -ForegroundColor Cyan
Write-Host "Username: $username" -ForegroundColor White
Write-Host "Password: $adPassword" -ForegroundColor White
Write-Host "Email: $userEmail" -ForegroundColor White

Write-Host "`nRemaining Manual Steps:" -ForegroundColor Yellow
Write-Host "1. Complete Exchange Online setup" -ForegroundColor White
Write-Host "2. Restart computer if domain join was performed" -ForegroundColor White
Write-Host "3. Test user login and verify all systems" -ForegroundColor White

# Open credentials file
$openFile = Read-Host "`nOpen credentials file? (Y/N)"
if ($openFile -eq 'Y' -or $openFile -eq 'y') {
    Start-Process notepad.exe $credentialsFile
}