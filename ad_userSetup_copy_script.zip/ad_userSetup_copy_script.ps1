# Enhanced PowerShell Script to Create AD User with Credentials Logging
# Processes the specific JSON format with sections and Q&A structure

param(
    [Parameter(Mandatory=$true)]
    [string]$ImportJsonFile,
    
    [switch]$ShowInfo,
    [switch]$DryRun
)

# Import Active Directory module
Import-Module ActiveDirectory -ErrorAction Stop

# Set the AD Server
$ADServer = "CGS-DC1"
Write-Host "Using Active Directory Server: $ADServer" -ForegroundColor Green

# Create credentials file path
$credentialsFile = ".\AD_User_Credentials_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"

# Prompt for administrative credentials
Write-Host "`n=== ADMINISTRATIVE CREDENTIALS REQUIRED ===" -ForegroundColor Yellow
Write-Host "Please provide domain administrator credentials for CGS-DC1" -ForegroundColor Yellow
Write-Host "Format: DOMAIN\username or username@domain.com" -ForegroundColor Gray

$Credential = Get-Credential -Message "Enter Domain Administrator Credentials for CGS-DC1"

if (-not $Credential) {
    Write-Error "Administrative credentials are required to create AD users"
    exit 1
}

Write-Host "✓ Credentials provided for: $($Credential.UserName)" -ForegroundColor Green

# Test AD connection with provided credentials
try {
    Write-Host "Testing connection to CGS-DC1..." -ForegroundColor Yellow
    $TestConnection = Get-ADDomain -Server $ADServer -Credential $Credential -ErrorAction Stop
    Write-Host "✓ Successfully connected to domain: $($TestConnection.Name)" -ForegroundColor Green
}
catch {
    Write-Error "Failed to connect to CGS-DC1 with provided credentials: $($_.Exception.Message)"
    exit 1
}

function Get-AnswerFromJson {
    param(
        [object]$JsonData,
        [string]$Question
    )
    
    foreach ($Section in $JsonData) {
        foreach ($Item in $Section.items) {
            if ($Item.question -eq $Question) {
                return $Item.answer
            }
        }
    }
    return $null
}

function Show-ImportInfo {
    param([object]$JsonData)
    
    Write-Host "=== IMPORT FILE ANALYSIS ===" -ForegroundColor Cyan
    
    foreach ($Section in $JsonData) {
        Write-Host "`n[$($Section.section)]" -ForegroundColor Yellow
        foreach ($Item in $Section.items) {
            if ($Item.answer -and $Item.answer -ne "n/a" -and $Item.answer -ne "") {
                Write-Host "  $($Item.question): $($Item.answer)" -ForegroundColor White
            }
        }
    }
}

function Validate-TemplateUser {
    param([string]$TemplateUser)
    
    # Define prohibited template users
    $ProhibitedTemplates = @(
        "teamlogic",
        "teamlogic2", 
        "Administrator",
        "Admin"
    )
    
    # Check if template user is prohibited
    if ($TemplateUser -in $ProhibitedTemplates) {
        Write-Host "`n=== TEMPLATE USER VALIDATION FAILED ===" -ForegroundColor Red
        Write-Host "ERROR: '$TemplateUser' cannot be used as a template user" -ForegroundColor Red
        Write-Host "Prohibited template accounts:" -ForegroundColor Yellow
        foreach ($Prohibited in $ProhibitedTemplates) {
            Write-Host "  - $Prohibited" -ForegroundColor Gray
        }
        Write-Host "`nReason: These are system/service accounts with inappropriate permissions" -ForegroundColor Yellow
        Write-Host "Please specify a regular user account as the template." -ForegroundColor Yellow
        throw "Template user '$TemplateUser' is prohibited"
    }
    
    try {
        $Template = Get-ADUser -Identity $TemplateUser -Properties Department, Title, MemberOf -Server $ADServer -Credential $Credential -ErrorAction Stop
        
        Write-Host "`n=== TEMPLATE USER VALIDATION ===" -ForegroundColor Cyan
        Write-Host "✓ Template user '$TemplateUser' is approved for use" -ForegroundColor Green
        Write-Host "Template User: $($Template.SamAccountName) - $($Template.Name)" -ForegroundColor Green
        Write-Host "Department: $($Template.Department)"
        Write-Host "Title: $($Template.Title)"
        
        $GroupCount = if ($Template.MemberOf) { $Template.MemberOf.Count } else { 0 }
        Write-Host "Group Memberships: $GroupCount"
        
        if ($GroupCount -gt 0) {
            Write-Host "`nGroup Memberships:" -ForegroundColor Yellow
            foreach ($Group in $Template.MemberOf | Select-Object -First 10) {
                try {
                    $GroupName = (Get-ADGroup -Identity $Group -Server $ADServer -Credential $Credential).Name
                    Write-Host "  - $GroupName" -ForegroundColor Gray
                }
                catch {
                    Write-Host "  - $Group" -ForegroundColor Gray
                }
            }
            if ($GroupCount -gt 10) {
                Write-Host "  ... and $($GroupCount - 10) more groups" -ForegroundColor Gray
            }
        }
        
        return $Template
    }
    catch {
        Write-Error "Template user '$TemplateUser' not found or inaccessible: $($_.Exception.Message)"
        return $null
    }
}

function Write-CredentialsLog {
    param(
        [string]$FilePath,
        [string]$FirstName,
        [string]$LastName,
        [string]$Username,
        [string]$Email,
        [string]$Password,
        [string]$TemplateUser,
        [string]$SetupType,
        [string]$Software,
        [string]$MobilePhone,
        [object]$GroupMemberships,
        [string]$Status
    )
    
    $logContent = @"
=== CGS ACTIVE DIRECTORY USER CREDENTIALS ===
Created: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Created By: $($Credential.UserName)

EMPLOYEE INFORMATION:
Name: $FirstName $LastName
Email: $Email
Setup Type: $SetupType
Mobile Phone: $MobilePhone

ACTIVE DIRECTORY ACCOUNT:
Username: $Username
Password: $Password
Domain: Austin.cgs
UPN: $Email
Status: $Status
Password Change Required: No

TEMPLATE USER:
Copied From: $TemplateUser
Template User Type: Regular Employee Account

PERMISSIONS COPIED:
Department: $($Template.Department)
Title: $($Template.Title)
Group Memberships: $($GroupMemberships.Count) groups

GROUP MEMBERSHIPS:
"@

    if ($GroupMemberships -and $GroupMemberships.Count -gt 0) {
        foreach ($Group in $GroupMemberships) {
            try {
                $GroupName = (Get-ADGroup -Identity $Group -Server $ADServer -Credential $Credential).Name
                $logContent += "`n  - $GroupName"
            }
            catch {
                $logContent += "`n  - $Group"
            }
        }
    } else {
        $logContent += "`n  No group memberships copied"
    }

    $logContent += @"

SOFTWARE REQUIREMENTS:
Required Software: $Software

NEXT STEPS:
1. Create Exchange Online mailbox for: $Email
2. Set up computer/device access
3. Install required software: $Software
4. Provide login credentials to employee
5. Verify all systems are working

IMPORTANT NOTES:
- Default password is set to: $Password
- Password change is NOT required at first login
- Employee should change password after initial setup
- Verify group permissions are appropriate for role

=== END OF CREDENTIALS LOG ===
"@

    $logContent | Out-File -FilePath $FilePath -Encoding UTF8
    Write-Host "✓ Credentials logged to: $FilePath" -ForegroundColor Green
}

try {
    # Read and parse the import JSON file
    if (-not (Test-Path $ImportJsonFile)) {
        throw "Import JSON file not found: $ImportJsonFile"
    }
    
    Write-Host "Reading import file: $ImportJsonFile" -ForegroundColor Green
    $ImportData = Get-Content $ImportJsonFile -Raw | ConvertFrom-Json
    
    # Show import information if requested
    if ($ShowInfo) {
        Show-ImportInfo -JsonData $ImportData
        return
    }
    
    # Extract information from JSON
    $FirstName = Get-AnswerFromJson -JsonData $ImportData -Question "First Name"
    $LastName = Get-AnswerFromJson -JsonData $ImportData -Question "Last Name"
    $UserEmail = Get-AnswerFromJson -JsonData $ImportData -Question "User Email?"
    $TemplateUser = Get-AnswerFromJson -JsonData $ImportData -Question "Is there an existing employee we can copy for file permissions?"
    $MobilePhone = Get-AnswerFromJson -JsonData $ImportData -Question "Mobile Phone"
    $SetupType = Get-AnswerFromJson -JsonData $ImportData -Question "New Setup or Transfer?"
    $Software = Get-AnswerFromJson -JsonData $ImportData -Question "What software does the employee need?"
    
    # Validate required fields
    if (-not $FirstName -or -not $LastName -or -not $UserEmail) {
        throw "Missing required information: First Name, Last Name, or User Email"
    }
    
    if (-not $TemplateUser -or $TemplateUser -eq "n/a") {
        throw "Template user not specified in import file"
    }
    
    # Extract username from email
    $NewUsername = $UserEmail.Split('@')[0]
    
    Write-Host "`n=== NEW USER INFORMATION ===" -ForegroundColor Cyan
    Write-Host "Name: $FirstName $LastName"
    Write-Host "Email: $UserEmail"
    Write-Host "Username: $NewUsername"
    Write-Host "Template User: $TemplateUser"
    Write-Host "Setup Type: $SetupType"
    if ($MobilePhone -and $MobilePhone -ne "TEST") {
        Write-Host "Mobile: $MobilePhone"
    }
    if ($Software) {
        Write-Host "Required Software: $Software"
    }
    
    # Validate template user exists and show permissions
    $Template = Validate-TemplateUser -TemplateUser $TemplateUser
    if (-not $Template) {
        throw "Cannot proceed without valid template user"
    }
    
    if ($DryRun) {
        Write-Host "`n=== DRY RUN - NO CHANGES MADE ===" -ForegroundColor Yellow
        Write-Host "Would create user '$NewUsername' copying from '$TemplateUser'"
        
        # Create dry run credentials log
        $dryRunFile = ".\AD_User_DryRun_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
        Write-CredentialsLog -FilePath $dryRunFile -FirstName $FirstName -LastName $LastName -Username $NewUsername -Email $UserEmail -Password "WelcomeCGSDB25" -TemplateUser $TemplateUser -SetupType $SetupType -Software $Software -MobilePhone $MobilePhone -GroupMemberships $Template.MemberOf -Status "DRY RUN - NOT CREATED"
        return
    }
    
    # Set the default password
    $Password = ConvertTo-SecureString "WelcomeCGSDB25" -AsPlainText -Force
    
    # Determine OU from template user
    $OU = ($Template.DistinguishedName -split ',', 2)[1]
    
    # Create hashtable with user properties
    $UserParams = @{
        SamAccountName = $NewUsername
        UserPrincipalName = $UserEmail
        Name = "$FirstName $LastName"
        DisplayName = "$FirstName $LastName"
        GivenName = $FirstName
        Surname = $LastName
        EmailAddress = $UserEmail
        AccountPassword = $Password
        Enabled = $true
        ChangePasswordAtLogon = $false
        Path = $OU
        
        # Copy properties from template
        Department = $Template.Department
        Title = $Template.Title
        Company = $Template.Company
        Office = $Template.Office
        Manager = $Template.Manager
        City = $Template.City
        State = $Template.State
        PostalCode = $Template.PostalCode
        Country = $Template.Country
    }
    
    # Add mobile phone if provided and not "TEST"
    if ($MobilePhone -and $MobilePhone -ne "TEST" -and $MobilePhone -ne "n/a") {
        $UserParams.MobilePhone = $MobilePhone
    }
    
    # Remove null values
    $CleanParams = @{}
    foreach ($key in $UserParams.Keys) {
        if ($UserParams[$key] -ne $null -and $UserParams[$key] -ne "") {
            $CleanParams[$key] = $UserParams[$key]
        }
    }
    
    Write-Host "`n=== CREATING USER ===" -ForegroundColor Cyan
    Write-Host "Creating user: $NewUsername in OU: $OU"
    
    # Create the new user
    New-ADUser @CleanParams -Server $ADServer -Credential $Credential
    Write-Host "✓ User account created successfully" -ForegroundColor Green
    
    # Copy group memberships from template
    $TemplateGroups = Get-ADUser -Identity $TemplateUser -Properties MemberOf -Server $ADServer -Credential $Credential | 
                     Select-Object -ExpandProperty MemberOf
    
    $SuccessfulGroups = @()
    if ($TemplateGroups) {
        Write-Host "`nCopying group memberships from $TemplateUser..." -ForegroundColor Yellow
        $SuccessCount = 0
        $FailCount = 0
        
        foreach ($Group in $TemplateGroups) {
            try {
                Add-ADGroupMember -Identity $Group -Members $NewUsername -Server $ADServer -Credential $Credential -ErrorAction Stop
                $GroupName = (Get-ADGroup -Identity $Group -Server $ADServer -Credential $Credential).Name
                Write-Host "  ✓ Added to: $GroupName" -ForegroundColor Green
                $SuccessfulGroups += $Group
                $SuccessCount++
            }
            catch {
                $GroupName = try { (Get-ADGroup -Identity $Group -Server $ADServer -Credential $Credential).Name } catch { $Group }
                Write-Host "  ✗ Failed to add to: $GroupName" -ForegroundColor Red
                Write-Host "    Error: $($_.Exception.Message)" -ForegroundColor Red
                $FailCount++
            }
        }
        
        Write-Host "`nGroup Membership Summary:" -ForegroundColor Cyan
        Write-Host "  Successfully copied: $SuccessCount groups" -ForegroundColor Green
        if ($FailCount -gt 0) {
            Write-Host "  Failed to copy: $FailCount groups" -ForegroundColor Red
        }
    }
    
    # Write credentials to log file
    Write-CredentialsLog -FilePath $credentialsFile -FirstName $FirstName -LastName $LastName -Username $NewUsername -Email $UserEmail -Password "WelcomeCGSDB25" -TemplateUser $TemplateUser -SetupType $SetupType -Software $Software -MobilePhone $MobilePhone -GroupMemberships $SuccessfulGroups -Status "Created Successfully"
    
    Write-Host "`n=== USER CREATION COMPLETE ===" -ForegroundColor Green
    Write-Host "Username: $NewUsername" -ForegroundColor White
    Write-Host "Email: $UserEmail" -ForegroundColor White
    Write-Host "Password: WelcomeCGSDB25 (no password change required)" -ForegroundColor White
    Write-Host "Template User: $TemplateUser" -ForegroundColor White
    Write-Host "Setup Type: $SetupType" -ForegroundColor White
    Write-Host "Credentials File: $credentialsFile" -ForegroundColor Yellow
    
    if ($Software) {
        Write-Host "`n=== SOFTWARE REQUIREMENTS ===" -ForegroundColor Yellow
        Write-Host "Required Software: $Software"
        Write-Host "Note: Software installation should be completed separately"
    }
    
    # Ask if user wants to open credentials file
    $openFile = Read-Host "`nOpen credentials file? (Y/N)"
    if ($openFile -eq 'Y' -or $openFile -eq 'y') {
        Start-Process notepad.exe $credentialsFile
    }
    
}
catch {
    Write-Error "Failed to create user: $($_.Exception.Message)"
    
    # Log failure
    if ($FirstName -and $LastName -and $UserEmail) {
        $failureFile = ".\AD_User_FAILED_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
        $failureContent = @"
=== CGS ACTIVE DIRECTORY USER CREATION FAILED ===
Attempted: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Attempted By: $($Credential.UserName)

EMPLOYEE INFORMATION:
Name: $FirstName $LastName
Email: $UserEmail

ERROR:
$($_.Exception.Message)

NEXT STEPS:
1. Review error message above
2. Verify template user exists and is accessible
3. Check domain connectivity
4. Retry user creation
"@
        $failureContent | Out-File -FilePath $failureFile -Encoding UTF8
        Write-Host "Error details logged to: $failureFile" -ForegroundColor Red
    }
    
    exit 1
}

<#
Usage Examples:

# Show information from import file
.\CreateADUser.ps1 -ImportJsonFile "Import.json" -ShowInfo

# Dry run - see what would be created without making changes
.\CreateADUser.ps1 -ImportJsonFile "Import.json" -DryRun

# Create the user and log credentials
.\CreateADUser.ps1 -ImportJsonFile "Import.json"
#>