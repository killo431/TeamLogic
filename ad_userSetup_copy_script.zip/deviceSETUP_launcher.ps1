# Device Setup/Transfer Launcher Script
# For existing employees getting new devices or transferring

param(
    [Parameter(Mandatory=$true)]
    [string]$JsonFilePath
)

Write-Host "=== CGS Device Setup/Transfer Launcher ===" -ForegroundColor Magenta
Write-Host "For existing employees - Device setup and software installation" -ForegroundColor Yellow

# Validate JSON file exists
if (-not (Test-Path $JsonFilePath)) {
    Write-Error "JSON file not found: $JsonFilePath"
    exit 1
}

# Read JSON to get employee info
try {
    $jsonContent = Get-Content -Path $JsonFilePath -Raw | ConvertFrom-Json
    
    # Extract employee name for display
    $firstName = ""
    $lastName = ""
    foreach ($section in $jsonContent) {
        foreach ($item in $section.items) {
            if ($item.question -eq "First Name") { $firstName = $item.answer }
            if ($item.question -eq "Last Name") { $lastName = $item.answer }
        }
    }
    
    Write-Host "Employee: $firstName $lastName" -ForegroundColor Green
}
catch {
    Write-Error "Failed to read JSON file: $($_.Exception.Message)"
    exit 1
}

Write-Host "`nThis launcher will:" -ForegroundColor Cyan
Write-Host "1. Join computer to domain Austin.cgs" -ForegroundColor White
Write-Host "2. Install required software" -ForegroundColor White

$confirm = Read-Host "`nProceed with device setup? (Y/N)"
if ($confirm -ne 'Y' -and $confirm -ne 'y') {
    Write-Host "Setup cancelled" -ForegroundColor Yellow
    exit 0
}

# Step 1: Domain Join
Write-Host "`n=== STEP 1: DOMAIN JOIN ===" -ForegroundColor Yellow
Write-Host "Executing domain join script..." -ForegroundColor Cyan

try {
    & ".\domain_join_script.ps1" -JsonFilePath $JsonFilePath
    if ($LASTEXITCODE -ne 0) {
        throw "Domain join failed"
    }
    Write-Host "✓ Domain join completed" -ForegroundColor Green
}
catch {
    Write-Error "Domain join failed: $($_.Exception.Message)"
    Write-Host "Please run domain join manually and then continue with software installation" -ForegroundColor Yellow
}

# Step 2: Software Installation
Write-Host "`n=== STEP 2: SOFTWARE INSTALLATION ===" -ForegroundColor Yellow
Write-Host "Installing required software..." -ForegroundColor Cyan

try {
    & ".\software_install_script.ps1" -JsonFilePath $JsonFilePath
    Write-Host "✓ Software installation completed" -ForegroundColor Green
}
catch {
    Write-Error "Software installation encountered errors: $($_.Exception.Message)"
}

Write-Host "`n=== DEVICE SETUP COMPLETE ===" -ForegroundColor Green
Write-Host "Employee: $firstName $lastName" -ForegroundColor White
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Restart computer to complete domain join" -ForegroundColor White
Write-Host "2. Login with domain credentials" -ForegroundColor White
Write-Host "3. Verify all software is working correctly" -ForegroundColor White