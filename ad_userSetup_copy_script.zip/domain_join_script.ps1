# PowerShell Script to Add PC to Domain using JSON Employee Data
# Domain: Austin.cgs

param(
    [Parameter(Mandatory=$true)]
    [string]$JsonFilePath,
    
    [Parameter(Mandatory=$false)]
    [string]$DomainUser,
    
    [Parameter(Mandatory=$false)]
    [SecureString]$DomainPassword
)

# Function to read and parse JSON file
function Get-EmployeeData {
    param([string]$FilePath)
    
    try {
        $jsonContent = Get-Content -Path $FilePath -Raw | ConvertFrom-Json
        return $jsonContent
    }
    catch {
        Write-Error "Failed to read or parse JSON file: $_"
        exit 1
    }
}

# Function to generate PC name based on template
function Get-PCName {
    param(
        [string]$FirstName,
        [string]$LastName
    )
    
    $currentYear = (Get-Date).Year
    $firstLetter = $FirstName.Substring(0,1).ToUpper()
    $pcName = "CGS-$firstLetter$LastName-$currentYear"
    
    # Ensure PC name doesn't exceed 15 characters (Windows NetBIOS limit)
    if ($pcName.Length -gt 15) {
        $pcName = $pcName.Substring(0, 15)
        Write-Warning "PC name truncated to 15 characters: $pcName"
    }
    
    return $pcName
}

# Function to get domain credentials if not provided
function Get-DomainCredentials {
    if (-not $DomainUser) {
        $DomainUser = Read-Host "Enter domain username (Austin.cgs\username)"
    }
    
    if (-not $DomainPassword) {
        $DomainPassword = Read-Host "Enter domain password" -AsSecureString
    }
    
    return New-Object System.Management.Automation.PSCredential($DomainUser, $DomainPassword)
}

# Main script execution
Write-Host "=== PC Domain Join Script ===" -ForegroundColor Green
Write-Host "Domain: Austin.cgs" -ForegroundColor Yellow

# Read employee data from JSON
Write-Host "Reading employee data from: $JsonFilePath" -ForegroundColor Cyan
$employeeData = Get-EmployeeData -FilePath $JsonFilePath

# Extract employee information
$firstName = ""
$lastName = ""
$userEmail = ""
$setupType = ""

foreach ($section in $employeeData) {
    if ($section.section -eq "Employee Information") {
        foreach ($item in $section.items) {
            switch ($item.question) {
                "First Name" { $firstName = $item.answer }
                "Last Name" { $lastName = $item.answer }
                "User Email?" { $userEmail = $item.answer }
                "New Setup or Transfer?" { $setupType = $item.answer }
            }
        }
    }
}

# Validate required data
if (-not $firstName -or -not $lastName) {
    Write-Error "First Name and Last Name are required from JSON file"
    exit 1
}

# Generate PC name
$newPCName = Get-PCName -FirstName $firstName -LastName $lastName

Write-Host "`nEmployee Information:" -ForegroundColor Yellow
Write-Host "  Name: $firstName $lastName"
Write-Host "  Email: $userEmail"
Write-Host "  Setup Type: $setupType"
Write-Host "  Generated PC Name: $newPCName" -ForegroundColor Green

# Get current PC name
$currentPCName = $env:COMPUTERNAME
Write-Host "  Current PC Name: $currentPCName"

# Confirm before proceeding
$confirmation = Read-Host "`nDo you want to proceed with renaming and joining domain? (Y/N)"
if ($confirmation -ne 'Y' -and $confirmation -ne 'y') {
    Write-Host "Operation cancelled by user" -ForegroundColor Red
    exit 0
}

try {
    # Get domain credentials
    Write-Host "`nGetting domain credentials..." -ForegroundColor Cyan
    $credentials = Get-DomainCredentials

    # Rename computer if needed
    if ($currentPCName -ne $newPCName) {
        Write-Host "Renaming computer to: $newPCName" -ForegroundColor Yellow
        Rename-Computer -NewName $newPCName -Force
        Write-Host "Computer renamed successfully" -ForegroundColor Green
    }

    # Join domain
    Write-Host "Joining domain: Austin.cgs" -ForegroundColor Yellow
    Add-Computer -DomainName "Austin.cgs" -Credential $credentials -Force
    
    Write-Host "`n=== SUCCESS ===" -ForegroundColor Green
    Write-Host "Computer successfully joined to Austin.cgs domain" -ForegroundColor Green
    Write-Host "PC Name: $newPCName" -ForegroundColor Green
    
    # Prompt for restart
    $restart = Read-Host "`nA restart is required to complete the domain join. Restart now? (Y/N)"
    if ($restart -eq 'Y' -or $restart -eq 'y') {
        Write-Host "Restarting computer in 10 seconds..." -ForegroundColor Yellow
        Start-Sleep -Seconds 10
        Restart-Computer -Force
    } else {
        Write-Host "Please restart the computer manually to complete the domain join process" -ForegroundColor Yellow
    }
}
catch {
    Write-Error "Failed to join domain: $_"
    Write-Host "`nTroubleshooting tips:" -ForegroundColor Yellow
    Write-Host "1. Verify domain credentials are correct"
    Write-Host "2. Ensure network connectivity to domain controller"
    Write-Host "3. Check if computer already exists in domain"
    Write-Host "4. Verify DNS settings point to domain controller"
    exit 1
}

# Log the operation
$logEntry = @{
    Timestamp = Get-Date
    Employee = "$firstName $lastName"
    Email = $userEmail
    PCName = $newPCName
    Domain = "Austin.cgs"
    Status = "Success"
}

$logPath = "C:\Temp\DomainJoin.log"
if (-not (Test-Path "C:\Temp")) {
    New-Item -ItemType Directory -Path "C:\Temp" -Force
}

$logEntry | ConvertTo-Json | Add-Content -Path $logPath
Write-Host "Operation logged to: $logPath" -ForegroundColor Cyan