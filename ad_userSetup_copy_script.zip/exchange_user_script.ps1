# Enhanced Exchange Online User Creation Script with JSON Configuration and Credentials Logging
# Requires: ExchangeOnlineManagement and Microsoft.Graph modules

param(
    [Parameter(Mandatory=$false)]
    [string]$JsonFilePath,
    
    [Parameter(Mandatory=$false)]
    [string]$ConfigPath = ".\UserConfig.json"
)

# Install required modules if not present
if (!(Get-Module -ListAvailable -Name ExchangeOnlineManagement)) {
    Install-Module -Name ExchangeOnlineManagement -Force -AllowClobber
}
if (!(Get-Module -ListAvailable -Name Microsoft.Graph)) {
    Install-Module -Name Microsoft.Graph -Force -AllowClobber
}

# Import modules
Import-Module ExchangeOnlineManagement
Import-Module Microsoft.Graph.Users
Import-Module Microsoft.Graph.Groups

# Create credentials file path
$credentialsFile = ".\Exchange_User_Credentials_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"

# Sample JSON Configuration (create this file separately)
$SampleConfig = @"
{
  "users": [
    {
      "firstName": "John",
      "lastName": "Doe",
      "displayName": "John Doe",
      "desiredEmailAddress": "john.doe@cgsdb.com",
      "userPrincipalName": "john.doe@cgsdb.com",
      "password": "WelcomeCGSDB25!",
      "jobTitle": "Software Developer",
      "department": "IT",
      "office": "Austin",
      "microsoftLicenses": [
        "Microsoft 365 E3"
      ],
      "distributionGroups": [
        "IT-Team@cgsdb.com",
        "All-Employees@cgsdb.com"
      ],
      "sharedMailboxes": [
        "support@cgsdb.com"
      ]
    }
  ]
}
"@

# Function to convert JSON employee data to user config
function Convert-JsonToUserConfig {
    param([string]$JsonPath)
    
    try {
        $jsonContent = Get-Content -Path $JsonPath -Raw | ConvertFrom-Json
        
        # Extract information from the JSON structure
        $firstName = ""
        $lastName = ""
        $email = ""
        $jobTitle = ""
        $mobile = ""
        $licenses = ""
        $distributionGroups = ""
        $sharedMailboxes = ""
        
        foreach ($section in $jsonContent) {
            foreach ($item in $section.items) {
                switch ($item.question) {
                    "First Name" { $firstName = $item.answer }
                    "Last Name" { $lastName = $item.answer }
                    "User Email?" { $email = $item.answer }
                    "Job Title/Position" { $jobTitle = $item.answer }
                    "Mobile Phone" { $mobile = $item.answer }
                    "Microsoft Licenses" { $licenses = $item.answer }
                    "Email Distribution Groups/Shared Mailboxes" { 
                        if ($item.answer -ne "n/a") {
                            $distributionGroups = $item.answer
                        }
                    }
                }
            }
        }
        
        # Create user config object
        $userConfig = @{
            firstName = $firstName
            lastName = $lastName
            displayName = "$firstName $lastName"
            desiredEmailAddress = $email
            userPrincipalName = $email
            password = "WelcomeCGSDB25!"
            jobTitle = $jobTitle
            department = "General"
            office = "Austin"
            microsoftLicenses = @()
            distributionGroups = @()
            sharedMailboxes = @()
        }
        
        # Parse licenses
        if ($licenses -and $licenses -ne "n/a") {
            if ($licenses -like "*E3*") {
                $userConfig.microsoftLicenses += "Microsoft 365 E3"
            }
            if ($licenses -like "*E5*") {
                $userConfig.microsoftLicenses += "Microsoft 365 E5"
            }
            if ($licenses -like "*Email only*" -or $licenses -like "*Office Web Apps*") {
                $userConfig.microsoftLicenses += "Microsoft 365 E3"
            }
        }
        
        # Parse distribution groups
        if ($distributionGroups -and $distributionGroups -ne "n/a") {
            $userConfig.distributionGroups = $distributionGroups -split "," | ForEach-Object { $_.Trim() }
        }
        
        # Add default distribution group
        $userConfig.distributionGroups += "All-Employees@cgsdb.com"
        
        return @{ users = @($userConfig) }
    }
    catch {
        Write-Error "Failed to convert JSON to user config: $($_.Exception.Message)"
        return $null
    }
}

# Function to create sample config file
function New-SampleConfig {
    if (!(Test-Path $ConfigPath)) {
        Write-Host "Creating sample configuration file at $ConfigPath" -ForegroundColor Yellow
        $SampleConfig | Out-File -FilePath $ConfigPath -Encoding UTF8
        Write-Host "Please edit the configuration file and run the script again." -ForegroundColor Green
        return $false
    }
    return $true
}

# Function to connect to services
function Connect-Services {
    try {
        Write-Host "Connecting to Exchange Online..." -ForegroundColor Cyan
        Connect-ExchangeOnline -UserPrincipalName "teamlogic@cgsdb.com" -ShowProgress $true
        
        Write-Host "Connecting to Microsoft Graph..." -ForegroundColor Cyan
        Connect-MgGraph -Scopes "User.ReadWrite.All", "Group.ReadWrite.All", "Directory.ReadWrite.All"
        
        Write-Host "Successfully connected to all services!" -ForegroundColor Green
        return $true
    }
    catch {
        Write-Error "Failed to connect to services: $($_.Exception.Message)"
        return $false
    }
}

# Function to get available licenses
function Get-AvailableLicenses {
    try {
        $licenses = Get-MgSubscribedSku | Select-Object SkuPartNumber, ConsumedUnits, @{Name="AvailableUnits";Expression={$_.PrepaidUnits.Enabled - $_.ConsumedUnits}}
        return $licenses
    }
    catch {
        Write-Warning "Could not retrieve license information: $($_.Exception.Message)"
        return @()
    }
}

# Function to map license names to SKU IDs
function Get-LicenseSkuId {
    param([string]$LicenseName)
    
    $licenseMap = @{
        "Microsoft 365 E3" = "SPE_E3"
        "Microsoft 365 E5" = "SPE_E5"
        "Microsoft 365 F3" = "SPE_F1"
        "Office 365 E1" = "STANDARDPACK"
        "Office 365 E3" = "ENTERPRISEPACK"
        "Office 365 E5" = "ENTERPRISEPREMIUM"
        "Microsoft 365 Business Basic" = "O365_BUSINESS_ESSENTIALS"
        "Microsoft 365 Business Standard" = "O365_BUSINESS_PREMIUM"
        "Microsoft 365 Business Premium" = "SPB"
    }
    
    return $licenseMap[$LicenseName]
}

# Function to write credentials log
function Write-ExchangeCredentialsLog {
    param(
        [string]$FilePath,
        [array]$CreatedUsers,
        [array]$FailedUsers
    )
    
    $logContent = @"
=== CGS EXCHANGE ONLINE USER CREDENTIALS ===
Created: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Created By: teamlogic@cgsdb.com

SUMMARY:
Successfully Created: $($CreatedUsers.Count) users
Failed to Create: $($FailedUsers.Count) users

"@

    if ($CreatedUsers.Count -gt 0) {
        $logContent += "`n=== SUCCESSFULLY CREATED USERS ===`n"
        foreach ($user in $CreatedUsers) {
            $logContent += @"

USER: $($user.displayName)
Email: $($user.userPrincipalName)
Password: $($user.password)
Job Title: $($user.jobTitle)
Department: $($user.department)
Office: $($user.office)
Status: Created Successfully

MICROSOFT LICENSES:
"@
            if ($user.assignedLicenses -and $user.assignedLicenses.Count -gt 0) {
                foreach ($license in $user.assignedLicenses) {
                    $logContent += "`n  - $license"
                }
            } else {
                $logContent += "`n  No licenses assigned"
            }

            $logContent += "`n`nDISTRIBUTION GROUPS:"
            if ($user.addedToGroups -and $user.addedToGroups.Count -gt 0) {
                foreach ($group in $user.addedToGroups) {
                    $logContent += "`n  - $group"
                }
            } else {
                $logContent += "`n  No distribution groups assigned"
            }

            $logContent += "`n`nSHARED MAILBOX ACCESS:"
            if ($user.sharedMailboxAccess -and $user.sharedMailboxAccess.Count -gt 0) {
                foreach ($mailbox in $user.sharedMailboxAccess) {
                    $logContent += "`n  - $mailbox (FullAccess)"
                }
            } else {
                $logContent += "`n  No shared mailbox access granted"
            }

            $logContent += "`n`n" + "="*50
        }
    }

    if ($FailedUsers.Count -gt 0) {
        $logContent += "`n`n=== FAILED USER CREATIONS ===`n"
        foreach ($user in $FailedUsers) {
            $logContent += @"

USER: $($user.displayName)
Email: $($user.userPrincipalName)
Status: FAILED
Error: $($user.error)

"@
        }
    }

    $logContent += @"

=== NEXT STEPS ===
1. Provide login credentials to new employees
2. Verify mailbox access is working
3. Test distribution group memberships
4. Confirm shared mailbox access permissions
5. Set up any additional required permissions

IMPORTANT NOTES:
- All users are set to change password on first login
- Exchange mailboxes may take 15-30 minutes to fully provision
- Distribution group membership may take up to 1 hour to replicate
- Shared mailbox access should be immediate after provisioning

=== END OF EXCHANGE CREDENTIALS LOG ===
"@

    $logContent | Out-File -FilePath $FilePath -Encoding UTF8
    Write-Host "✓ Exchange credentials logged to: $FilePath" -ForegroundColor Green
}

# Function to create a new user
function New-ExchangeUser {
    param([PSCustomObject]$UserConfig)
    
    $userResult = @{
        displayName = $UserConfig.displayName
        userPrincipalName = $UserConfig.userPrincipalName
        password = $UserConfig.password
        jobTitle = $UserConfig.jobTitle
        department = $UserConfig.department
        office = $UserConfig.office
        assignedLicenses = @()
        addedToGroups = @()
        sharedMailboxAccess = @()
        status = "Failed"
        error = ""
    }
    
    try {
        Write-Host "Creating user: $($UserConfig.displayName)" -ForegroundColor Cyan
        
        # Create the user in Azure AD via Microsoft Graph
        $passwordProfile = @{
            Password = $UserConfig.password
            ForceChangePasswordNextSignIn = $true
        }
        
        $userParams = @{
            DisplayName = $UserConfig.displayName
            GivenName = $UserConfig.firstName
            Surname = $UserConfig.lastName
            UserPrincipalName = $UserConfig.userPrincipalName
            Mail = $UserConfig.desiredEmailAddress
            JobTitle = $UserConfig.jobTitle
            Department = $UserConfig.department
            OfficeLocation = $UserConfig.office
            PasswordProfile = $passwordProfile
            AccountEnabled = $true
        }
        
        $newUser = New-MgUser @userParams
        Write-Host "✓ User created in Azure AD: $($newUser.UserPrincipalName)" -ForegroundColor Green
        
        # Wait for user propagation
        Start-Sleep -Seconds 10
        
        # Assign licenses
        if ($UserConfig.microsoftLicenses) {
            Write-Host "Assigning licenses..." -ForegroundColor Yellow
            foreach ($license in $UserConfig.microsoftLicenses) {
                try {
                    $skuId = Get-LicenseSkuId -LicenseName $license
                    if ($skuId) {
                        $licenseDetails = Get-MgSubscribedSku | Where-Object {$_.SkuPartNumber -eq $skuId}
                        if ($licenseDetails) {
                            $licenseObject = @{
                                SkuId = $licenseDetails.SkuId
                            }
                            Set-MgUserLicense -UserId $newUser.Id -AddLicenses @($licenseObject) -RemoveLicenses @()
                            Write-Host "✓ Assigned license: $license" -ForegroundColor Green
                            $userResult.assignedLicenses += $license
                        }
                        else {
                            Write-Warning "License not found or not available: $license"
                        }
                    }
                    else {
                        Write-Warning "Unknown license type: $license"
                    }
                }
                catch {
                    Write-Warning "Failed to assign license $license`: $($_.Exception.Message)"
                }
            }
        }
        
        # Wait for Exchange mailbox creation
        Write-Host "Waiting for Exchange mailbox creation..." -ForegroundColor Yellow
        $timeout = (Get-Date).AddMinutes(5)
        do {
            Start-Sleep -Seconds 15
            $mailbox = Get-Mailbox -Identity $UserConfig.userPrincipalName -ErrorAction SilentlyContinue
        } while (!$mailbox -and (Get-Date) -lt $timeout)
        
        if ($mailbox) {
            Write-Host "✓ Exchange mailbox created successfully" -ForegroundColor Green
            
            # Add to distribution groups
            if ($UserConfig.distributionGroups) {
                Write-Host "Adding to distribution groups..." -ForegroundColor Yellow
                foreach ($group in $UserConfig.distributionGroups) {
                    try {
                        Add-DistributionGroupMember -Identity $group -Member $UserConfig.userPrincipalName -ErrorAction Stop
                        Write-Host "✓ Added to distribution group: $group" -ForegroundColor Green
                        $userResult.addedToGroups += $group
                    }
                    catch {
                        Write-Warning "Failed to add to distribution group $group`: $($_.Exception.Message)"
                    }
                }
            }
            
            # Grant access to shared mailboxes (FullAccess only, no SendAs)
            if ($UserConfig.sharedMailboxes) {
                Write-Host "Granting access to shared mailboxes..." -ForegroundColor Yellow
                foreach ($sharedMailbox in $UserConfig.sharedMailboxes) {
                    try {
                        # Grant FullAccess permission only
                        Add-MailboxPermission -Identity $sharedMailbox -User $UserConfig.userPrincipalName -AccessRights FullAccess -InheritanceType All -ErrorAction Stop
                        Write-Host "✓ Granted FullAccess to shared mailbox: $sharedMailbox" -ForegroundColor Green
                        $userResult.sharedMailboxAccess += $sharedMailbox
                    }
                    catch {
                        Write-Warning "Failed to grant access to shared mailbox $sharedMailbox`: $($_.Exception.Message)"
                    }
                }
            }
            
            $userResult.status = "Success"
        }
        else {
            $userResult.error = "Exchange mailbox was not created within the timeout period"
            Write-Warning $userResult.error
        }
        
        Write-Host "User creation completed: $($UserConfig.displayName)" -ForegroundColor Green
        Write-Host "----------------------------------------" -ForegroundColor Gray
        
    }
    catch {
        $userResult.error = $_.Exception.Message
        Write-Error "Failed to create user $($UserConfig.displayName): $($_.Exception.Message)"
    }
    
    return $userResult
}

# Main execution
function Main {
    Write-Host "Enhanced Exchange Online User Creation Script" -ForegroundColor Magenta
    Write-Host "=============================================" -ForegroundColor Magenta
    
    $config = $null
    
    # Check if JSON file path is provided
    if ($JsonFilePath -and (Test-Path $JsonFilePath)) {
        Write-Host "Converting JSON employee data to user configuration..." -ForegroundColor Cyan
        $config = Convert-JsonToUserConfig -JsonPath $JsonFilePath
        if (-not $config) {
            return
        }
        Write-Host "✓ JSON data converted successfully" -ForegroundColor Green
    }
    else {
        # Check if config file exists, create sample if not
        if (!(New-SampleConfig)) {
            return
        }
        
        # Load configuration
        try {
            $config = Get-Content -Path $ConfigPath -Raw | ConvertFrom-Json
            Write-Host "Loaded configuration for $($config.users.Count) user(s)" -ForegroundColor Green
        }
        catch {
            Write-Error "Failed to load configuration file: $($_.Exception.Message)"
            return
        }
    }
    
    # Connect to services
    if (!(Connect-Services)) {
        return
    }
    
    # Display available licenses
    Write-Host "`nAvailable Licenses:" -ForegroundColor Cyan
    $availableLicenses = Get-AvailableLicenses
    $availableLicenses | Format-Table -AutoSize
    
    # Show user information
    Write-Host "`nUsers to be created:" -ForegroundColor Cyan
    foreach ($user in $config.users) {
        Write-Host "- $($user.displayName) ($($user.userPrincipalName))" -ForegroundColor White
    }
    
    # Confirm before proceeding
    $confirmation = Read-Host "`nDo you want to proceed with creating $($config.users.Count) user(s)? (Y/N)"
    if ($confirmation -ne 'Y' -and $confirmation -ne 'y') {
        Write-Host "Operation cancelled." -ForegroundColor Yellow
        return
    }
    
    # Create users and track results
    $createdUsers = @()
    $failedUsers = @()
    
    foreach ($user in $config.users) {
        $result = New-ExchangeUser -UserConfig $user
        if ($result.status -eq "Success") {
            $createdUsers += $result
        } else {
            $failedUsers += $result
        }
    }
    
    # Write credentials log
    Write-ExchangeCredentialsLog -FilePath $credentialsFile -CreatedUsers $createdUsers -FailedUsers $failedUsers
    
    Write-Host "`n=== EXCHANGE SETUP COMPLETE ===" -ForegroundColor Green
    Write-Host "Successfully created: $($createdUsers.Count) users" -ForegroundColor Green
    if ($failedUsers.Count -gt 0) {
        Write-Host "Failed to create: $($failedUsers.Count) users" -ForegroundColor Red
    }
    Write-Host "Credentials file: $credentialsFile" -ForegroundColor Yellow
    
    # Ask if user wants to open credentials file
    $openFile = Read-Host "`nOpen credentials file? (Y/N)"
    if ($openFile -eq 'Y' -or $openFile -eq 'y') {
        Start-Process notepad.exe $credentialsFile
    }
    
    Write-Host "`nDon't forget to disconnect from services when done:" -ForegroundColor Yellow
    Write-Host "Disconnect-ExchangeOnline" -ForegroundColor White
    Write-Host "Disconnect-MgGraph" -ForegroundColor White
}

# Run the script
Main

<#
Usage Examples:

# Create user from JSON employee data
.\ExchangeUserScript.ps1 -JsonFilePath "employee_onboarding.json"

# Use traditional config file method
.\ExchangeUserScript.ps1 -ConfigPath "UserConfig.json"

# Use default config file
.\ExchangeUserScript.ps1
#>