# Software Installation Script
# Reads JSON file and installs only requested software

param(
    [Parameter(Mandatory=$true)]
    [string]$JsonFilePath
)

# Define all available software installations with silent and skip agreement flags
$SoftwareCommands = @{
    "Slack" = "winget install SlackTechnologies.Slack --silent --accept-package-agreements --accept-source-agreements"
    "Zoom" = "winget install Zoom.Zoom --silent --accept-package-agreements --accept-source-agreements"
    "Adobe Reader" = "winget install Adobe.Acrobat.Reader.64-bit --silent --accept-package-agreements --accept-source-agreements"
    "Adobe Pro" = "winget install Adobe.Acrobat.Pro --silent --accept-package-agreements --accept-source-agreements"
    "Office" = "winget install Microsoft.Office --silent --accept-package-agreements --accept-source-agreements"
    "Firefox" = "winget install Mozilla.Firefox --silent --accept-package-agreements --accept-source-agreements"
    "Egnyte" = "winget install Egnyte.EgnyteDesktopApp --silent --accept-package-agreements --accept-source-agreements"
    "AutoCAD" = "winget install Autodesk.AutoCAD --silent --accept-package-agreements --accept-source-agreements"
    "Chrome" = "winget install Google.Chrome --silent --accept-package-agreements --accept-source-agreements"
}

try {
    # Read and parse JSON file
    $jsonContent = Get-Content -Path $JsonFilePath -Raw | ConvertFrom-Json
    
    # Find the software question
    $softwareAnswer = ""
    foreach ($section in $jsonContent) {
        foreach ($item in $section.items) {
            if ($item.question -eq "What software does the employee need?") {
                $softwareAnswer = $item.answer
                break
            }
        }
        if ($softwareAnswer -ne "") { break }
    }
    
    if ($softwareAnswer -eq "") {
        Write-Host "Software question not found in JSON file" -ForegroundColor Red
        exit 1
    }
    
    Write-Host "Found software requirements: $softwareAnswer" -ForegroundColor Green
    
    # Parse the software list (remove quotes and split)
    $requestedSoftware = $softwareAnswer -replace "'", "" -split "\s+" | Where-Object { $_ -ne "" }
    
    Write-Host "`nInstalling requested software:" -ForegroundColor Yellow
    
    # Execute installation commands for requested software
    foreach ($software in $requestedSoftware) {
        if ($SoftwareCommands.ContainsKey($software)) {
            Write-Host "Installing $software..." -ForegroundColor Cyan
            $command = $SoftwareCommands[$software]
            Write-Host "Executing: $command" -ForegroundColor Gray
            
            # Execute the winget command
            Invoke-Expression $command
            
            if ($LASTEXITCODE -eq 0) {
                Write-Host "✓ $software installed successfully" -ForegroundColor Green
            } else {
                Write-Host "✗ Failed to install $software" -ForegroundColor Red
            }
        } else {
            Write-Host "⚠ Unknown software: $software" -ForegroundColor Yellow
        }
    }
    
    Write-Host "`nInstallation process completed!" -ForegroundColor Green
    
} catch {
    Write-Host "Error processing JSON file: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Display available software commands for reference
Write-Host "`n--- Available Software Commands ---" -ForegroundColor Magenta
$SoftwareCommands.GetEnumerator() | Sort-Object Name | ForEach-Object {
    Write-Host "$($_.Key): $($_.Value)" -ForegroundColor Gray
}